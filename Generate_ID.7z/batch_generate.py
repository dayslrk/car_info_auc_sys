from tkinter import *
import random

def random_vin(car_category='哈飞汽车',date='2001',type='ecu',no=0,original=0):
    vinMapKey ={
'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5,
'F': 6, 'G': 7, 'H': 8, 'I': 0, 'J': 1, 'K': 2, 'L': 3,
'M': 4, 'N': 5, 'O': 0, 'P': 7, 'Q': 8, 'R': 9, 'S': 2, 'T': 3,
'U': 4, 'V': 5, 'W': 6, 'X': 7, 'Y': 8, 'Z': 9, "0": 0, "1": 1,
"2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9}
    vinMapValue = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2]
    type_list={'01':"9",'02':"8",'03':"7"}
    categorys = {'上海大众': 'LSV', '一汽大众': 'LFV', '神龙富康': 'LDC', '北京吉普': 'LEN',
'广州本田': 'LHG', '北汽福田': 'LHB', '哈飞汽车': 'LKD', '长安汽车': 'LS5',
'上海通用': 'LSG', '北京现代': 'LNB', '南京菲亚特': 'LNP', '一汽轿车': 'LFP',
'宝马': 'LBV', '福特': '1LN'}

    datelist={'2001':"1",'2002':"2",'2003':"3",'2004':"4",'2005':"5",'2006':"6",'2007':"7",'2008':"8",
              '2009': "9",'2010':"A",'2011':"B",'2012':"C",'2013':"D",'2014':"E",'2015':"F",'2016':"G",'2017':"H",
              '2018': "J", '2019': "K",'2020':"L",'2021':"M",'2022':"N",'2023':"P",
              '2024': "R", '2025': "S",'2026':"T",'2027':"V",'2028':"W",'2029':"X",'2030':"Y"
              }
    vin = ''.join(random.sample('ABCDEFGHJKLMPRSTUVWXYZ0123456789', 14))
    date=datelist[date]
    num = 0
    if type in type_list:
        type=type_list[type]
    if car_category is None:

        wmi = categorys['宝马']
        vin = wmi + vin
    else:
        wmi = categorys[car_category]
        vin = wmi + vin
    tmp=list(vin)
    tmp[4]=str(type)#第5位为ecu类型
    tmp[9]=str(date)#第十位表示时间
    tmp[10]=str(original)#原装厂表示0，否则表示1,默认是0
    no=str(no)
    len0=6-len(no)
    if len0==0:
        tmp[11:17]=no#15-17，顺序号
    else:
        tmp[11:17] = "0"*len0+no
    vin=''.join(tmp)
    for i in range(len(vin)):
        num = num + vinMapKey[vin[i]] * vinMapValue[i]
        ninth = num % 11
        if ninth == 10:
            ninth = 'X'
        list_arr = list(vin)
        list_arr[8] = str(ninth)#校验位
        vin = ''.join(list_arr)
    return vin

import pandas as pd

def process_file_1(file_name):
    sheet = pd.read_excel(file_name).values

    for i in range(sheet.shape[0]):
        vin=random_vin(str(sheet[i][0]),str(sheet[i][1]),str(sheet[i][2]),sheet[i][3],sheet[i][4])
        with open('vin.txt','a') as f:
            f.write(str(i)+','+vin+'\n')
        f.close()
if __name__ == '__main__':
    process_file_1('1.xlsx')