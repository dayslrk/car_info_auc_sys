from tkinter import *
import random

def random_vin(car_category='哈飞汽车',date='2001',type='ecu',no=0,original=0):
    vinMapKey ={
'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5,
'F': 6, 'G': 7, 'H': 8, 'I': 0, 'J': 1, 'K': 2, 'L': 3,
'M': 4, 'N': 5, 'O': 0, 'P': 7, 'Q': 8, 'R': 9, 'S': 2, 'T': 3,
'U': 4, 'V': 5, 'W': 6, 'X': 7, 'Y': 8, 'Z': 9, "0": 0, "1": 1,
"2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9}
    vinMapValue = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2]
    type_list={'01':"9",'02':"8",'03':"7"}
    categorys = {'上海大众': 'LSV', '一汽大众': 'LFV', '神龙富康': 'LDC', '北京吉普': 'LEN',
'广州本田': 'LHG', '北汽福田': 'LHB', '哈飞汽车': 'LKD', '长安汽车': 'LS5',
'上海通用': 'LSG', '北京现代': 'LNB', '南京菲亚特': 'LNP', '一汽轿车': 'LFP',
'宝马': 'LBV', '福特': '1LN'}

    datelist={'2001':"1",'2002':"2",'2003':"3",'2004':"4",'2005':"5",'2006':"6",'2007':"7",'2008':"8",
              '2009': "9",'2010':"A",'2011':"B",'2012':"C",'2013':"D",'2014':"E",'2015':"F",'2016':"G",'2017':"H",
              '2018': "J", '2019': "K",'2020':"L",'2021':"M",'2022':"N",'2023':"P",
              '2024': "R", '2025': "S",'2026':"T",'2027':"V",'2028':"W",'2029':"X",'2030':"Y"
              }
    vin = ''.join(random.sample('ABCDEFGHJKLMPRSTUVWXYZ0123456789', 14))
    date=datelist[date]
    num = 0
    if type in type_list:
        type=type_list[type]
    if car_category is None:

        wmi = categorys['宝马']
        vin = wmi + vin
    else:
        wmi = categorys[car_category]
        vin = wmi + vin
    tmp=list(vin)
    tmp[4]=str(type)#第5位为ecu类型
    tmp[9]=str(date)#第十位表示时间
    tmp[10]=original#原装厂表示0，否则表示1,默认是0
    tmp[11:17]=str(no)#15-17，顺序号
    vin=''.join(tmp)
    for i in range(len(vin)):
        num = num + vinMapKey[vin[i]] * vinMapValue[i]
        ninth = num % 11
        if ninth == 10:
            ninth = 'X'
        list_arr = list(vin)
        list_arr[8] = str(ninth)#校验位
        vin = ''.join(list_arr)
    return vin

def submit():
    print(u.get())
    print(p.get())
    print(c.get())
    print(d.get())
    print(e.get())

    vin=random_vin(u.get(),p.get(),c.get(),d.get(),e.get())
    no.set(vin)
root = Tk()
root.title("配件ID生成")
frame = Frame(root)
frame.pack(padx=8, pady=8, ipadx=4)

lab1 = Label(frame, text="出厂商:")
lab1.grid(row=0, column=0, padx=5, pady=5, sticky=W)
u = StringVar()
ent1 = Entry(frame, textvariable=u)
ent1.grid(row=0, column=1, sticky='ew', columnspan=2)

lab2 = Label(frame, text="生产日期:")
lab2.grid(row=1, column=0, padx=5, pady=5, sticky=W)
p = StringVar()
ent2 = Entry(frame, textvariable=p)
ent2.grid(row=1, column=1, sticky='ew', columnspan=2)

labx = Label(frame, text="型号:")
labx.grid(row=2, column=0, padx=5, pady=5, sticky=W)
c = StringVar()
ent2 = Entry(frame, textvariable=c)
ent2.grid(row=2, column=1, sticky='ew', columnspan=2)

labt = Label(frame, text="序号:")
labt.grid(row=3, column=0, padx=5, pady=5, sticky=W)
d = StringVar()
ent2 = Entry(frame, textvariable=d)
ent2.grid(row=3, column=1, sticky='ew', columnspan=2)

labz = Label(frame, text="原装厂标志位(0):")
labz.grid(row=4, column=0, padx=5, pady=5, sticky=W)
e = StringVar()
ent2 = Entry(frame, textvariable=e)
ent2.grid(row=4, column=1, sticky='ew', columnspan=2)

labno = Label(frame, text="ID:")
labno.grid(row=5, column=0, padx=5, pady=5, sticky=W)
no = StringVar()
ent3 = Entry(frame, textvariable=no)
ent3.grid(row=5, column=1, sticky='ew', columnspan=2)





button = Button(frame, text="生成", command=submit, default='active')
button.grid(row=6, column=1)
lab3 = Label(frame, text="")
lab3.grid(row=6, column=0, sticky=W)
button2 = Button(frame, text="退出", command=quit)
button2.grid(row=6, column=2, padx=5, pady=5)

#以下代码居中显示窗口

root.update_idletasks()
x = (root.winfo_screenwidth() - root.winfo_reqwidth()) / 2
y = (root.winfo_screenheight() - root.winfo_reqheight()) / 2
root.geometry("+%d+%d" % (x, y))
root.mainloop()