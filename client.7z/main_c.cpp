#include <iostream>

#include <cstring>
#include<stdio.h>
#include "client.h"

void get_hmac(const char* dev,const char* challenge,const char* ip)
{
    std::cout << "=====client start main=====" << '\n';

    ssl_tls tls;
    tls.two_way_auth = true;
#if 0
    tls.ca_certf = std::string("etc/centos7/ca.crt");
    tls.certf    = std::string("etc/centos7/client.crt");
    tls.private_key  = std::string("etc/centos7/client.key");
    tls.passwd  = std::string("uway123");
#else
    tls.ca_certf = std::string("etc/ubuntu18/cacert.pem");
    tls.certf    = std::string("etc/ubuntu18/client.crt");
    tls.private_key  = std::string("etc/ubuntu18/client.key");
    tls.passwd  = std::string("yyp123");
#endif
    tls.meth = TLSv1_client_method();

    std::shared_ptr<client> c = std::make_shared<client>(ip, 9999, tls);
    // std::shared_ptr<client> c = std::make_shared<client>("127.0.0.1", 9999);
    if (c->initial() == false)
    {
        std::cout << "client initial error!" << '\n';
        return ;
    }

    char buffer[1024] = {0};
   
    
for(int i=0;i<1;i++)
{
        int ret = c->send_msg(dev, strlen(dev));
        if (ret < 0)
        {
            std::cout << "send_msg error!" << '\n';
            break;
        }
        memset(buffer,0,1024);
        ret = c->recv_msg(buffer, 1024);
        if (ret < 0)
        {
            std::cout << "recv_msg error!" << '\n';
            break;
        }

        buffer[ret] = '\0';
       // std::cout << "\033[32mclient fd: " << c->get_socket_fd() << ", recv msg: " << buffer << "\033[0m" << '\n';

        memset(buffer,0,1024);

        ret=c->send_msg(challenge,strlen(challenge));
        if (ret < 0)
        {
            std::cout << "send_msg error!" << '\n';
            break;
        }

        ret = c->recv_msg(buffer, 1024);
        if (ret < 0)
        {
            std::cout << "recv_msg error!" << '\n';
            break;
        }

        buffer[ret] = '\0';
printf("HMAC from server:\n");
	for(int i=0;i<32;i++)
{
printf("%02x",(unsigned char)buffer[i]);

}
printf("\n");
       // std::cout << "\033[32mclient fd: " << c->get_socket_fd() << ", recv msg: " << buffer << "\033[0m" << '\n';
        memset(buffer,0,1024);
    }
    
    std::cout << "=====client end main=====" << '\n';

}
int main(int argc,char** argv)
{
    if(argc!=3)
    return 0;
    const char* dev=(const char*)argv[1];
    const char* challenge=(const char*)argv[2];
    const char* ip=(const char*)argv[3];
    get_hmac(dev,challenge);

    return 0;
}
