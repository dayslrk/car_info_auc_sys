#ifndef CONNECT_H_INCLUDED
#define CONNECT_H_INCLUDED


#include<iostream>
#include<string>
#include<mysql/mysql.h>
#include<string.h>
#ifdef __cplusplus


extern "C"{
#endif // __cplusplus

char *connect_sql(const char *dev);
#ifdef __cplusplus
}
#endif

#endif // CONNECT_H_INCLUDED
