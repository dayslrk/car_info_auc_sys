<?php
// 连接数据库、设置字符集
$link = mysqli_connect('127.0.0.1', 'root', '123456', 'mysql');
mysqli_set_charset($link, 'utf8');

?>