<?php
header("Content-Type:text/html;charset=utf-8");
echo "登陆失败<br/>用户名或密码错误";
 
?>